from .database import Base
from sqlalchemy import String, Integer, Column, ForeignKey, BigInteger
from sqlalchemy.orm import relationship


class Plant(Base):
    __tablename__ = "plants"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255))
    region = Column(String(255))
    user_id = Column(Integer, ForeignKey('users.id'))
    plant_buyer = relationship("User", back_populates='user_interact')

class Fertilizer(Base):
    __tablename__ = "fertilizers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255))
    size = Column(Integer)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255))
    password = Column(String(255))
    email = Column(String(255))
    user_interact=relationship("Plant", back_populates="plant_buyer")


