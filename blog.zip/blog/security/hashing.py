from passlib.context import CryptContext

pass_hash = CryptContext(schemes=["bcrypt"], deprecated = "auto")
class Hash():
    @staticmethod
    def bcrypt(password: str):   
        return pass_hash.hash(password)