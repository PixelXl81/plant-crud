from pydantic import BaseModel

class RequestSchema(BaseModel):
    id : int
    name : str
    region : str

class FertilizerRequestSchema(BaseModel):
    id : int
    name : str
    size : int

class UserRequestSchema(BaseModel):
    name : str
    password : str
    email: str | None = None