from pydantic import BaseModel
from typing import Optional, List

class FertilizerResponseSchema(BaseModel):
    name: str
    size: int

class UserResponseSchema(BaseModel):
    id: int
    name: str
    email: Optional[str] = None

    class Config:
        orm_mode = True

# Pydantic submodel for the Plant
class PlantResponseSchema(BaseModel):
    id: int
    name: str
    region: str
    user_id: int
    # This will represent the list of users associated with the plant
    plant_buyer: UserResponseSchema

    class Config:
        orm_mode = True