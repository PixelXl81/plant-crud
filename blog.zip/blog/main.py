from fastapi import FastAPI, Depends, status, Response, HTTPException, APIRouter
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session
from .schema.requestschema import RequestSchema, FertilizerRequestSchema, UserRequestSchema
from .database import models
from .database.database import engine, SessionLocal
from blog.schema.responesschema import PlantResponseSchema, FertilizerResponseSchema, UserResponseSchema
from passlib.context import CryptContext
from .security.hashing import Hash
app = FastAPI()

hash = Hash()
models.Base.metadata.create_all(engine) # adding the things to the database 

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/blog/plants/all_plants", response_model=list[PlantResponseSchema], status_code= status.HTTP_200_OK, tags=["plants"])
def all_plants(db: Session = Depends(get_db)):
    plants = db.query(models.Plant).all()
    if not plants:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="your content is not available")
    return plants        

@app.get("/blog/plants/{id}", response_model=PlantResponseSchema, status_code=status.HTTP_202_ACCEPTED, tags=["plants"])
def one_plant(id: int, db: Session = Depends(get_db)):
    plant = db.query(models.Plant).filter(models.Plant.id == id).one_or_none()
    if not plant:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Plant not found")
    return plant

@app.post("/blog/plants", status_code=status.HTTP_201_CREATED, tags=["plants"])
def create_plant(request:RequestSchema, db: Session = Depends(get_db)):
    new_plant = models.Plant(name=request.name, region=request.region, user_id = 1)
    db.add(new_plant)
    db.commit()
    db.refresh(new_plant)
    return new_plant

@app.put("/blog/plants/{id}", status_code=status.HTTP_202_ACCEPTED, tags=["plants"])
def update_plant(id, request: RequestSchema, db: Session=Depends(get_db)):
    updated_plant = jsonable_encoder(request)
    updated_plant_data = db.query(models.Plant).filter(models.Plant.id == id)
    existing_data = updated_plant_data.first()
    if existing_data:
        updated_plant_data.update(updated_plant)
        db.commit()
        return{"message":"data successfully updated"}
    else:
        raise HTTPException(status_code=status.HTTP_406_NOT_ACCEPTABLE, detail="this mean that you can't update your data or id is unavaillable")
    
@app.delete("/blog/plants/{id}", status_code= status.HTTP_200_OK, tags=["plants"])
def delete_plant(id, db: Session = Depends(get_db)):
    plant = db.query(models.Plant).filter(models.Plant.id == id).delete()
    db.commit()
    if  plant == 1:
        return "successfully delete"    
    else:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"the {id} that you want to delete is not available")




@app.get("/blog/fertilizers/all_fertilizers", response_model=list[FertilizerResponseSchema], status_code=status.HTTP_200_OK, tags=["fertillizers"])
def all_fertilizers(db: Session = Depends(get_db)):
    all_fertilizers_value = db.query(models.Fertilizer).all()
    if not all_fertilizers:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="no value is available")
    return all_fertilizers_value

@app.get("/blog/fertilizers/{id}", tags=["fertillizers"], status_code=status.HTTP_200_OK)
def one_fertilizer(id, db: Session = Depends(get_db)):
    fertilizer = db.query(models.Fertilizer).filter(models.Fertilizer.id == id).one_or_none()
    if not fertilizer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"this {id} is not available")
    return fertilizer

@app.post("/blog/fertilizers", status_code=status.HTTP_201_CREATED, tags=["fertillizers"])
def create_fertilizers(request: FertilizerRequestSchema, db: Session = Depends(get_db)):
    new_fertilizer = models.Fertilizer(name = request.name, size = request.size)
    db.add(new_fertilizer)
    db.commit()
    db.refresh(new_fertilizer)
    return new_fertilizer

@app.put("/blog/fertilizer/{id}", status_code=status.HTTP_202_ACCEPTED, tags=["fertillizers"])
def update_fertilizer(id, request: FertilizerRequestSchema, db: Session = Depends(get_db)):

    updated_fertilizer = jsonable_encoder(request)
    update_fertilizer_data = db.query(models.Fertilizer).filter(models.Fertilizer.id == id)
    existing_data = update_fertilizer_data.first()
    if  existing_data:
        update_fertilizer_data.update(updated_fertilizer, synchronize_session=False)
        db.commit()
        return{"message": "your fertillizer has been successfully updated"}
    else:
        raise HTTPException(status_code=status.HTTP_406_NOT_ACCEPTABLE, detail="your fertillizer or your id is not availllable to insert")
    
@app.delete("/blog/fertilizer/{id}", status_code=status.HTTP_200_OK, tags=["fertillizers"])
def delete_fertillizer(id, db: Session = Depends(get_db)):
    deleting_fertilizer = db.query(models.Fertilizer).filter(models.Fertilizer.id == id).delete()
    if deleting_fertilizer == 1:
        return{"message": "this fertillizer successfully deleted"}
    else:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="this id isn't availlable or you don't have the premission to delete this id ")
    

@app.post("/blog/user", tags=["users"])
def create_user(request : UserRequestSchema, db: Session = Depends(get_db)):
    creating_user = models.User(name = request.name, password = Hash.bcrypt(request.password), email = request.email)
    db.add(creating_user)
    db.commit()
    db.refresh(creating_user)
    return creating_user

@app.get("/blog/user/{id}", response_model=list[UserResponseSchema], status_code=status.HTTP_200_OK, tags=["users"])
def get_user(id: int, db: Session = Depends(get_db)):
    getting_user = db.query(models.User).filter(models.User.id == id).one_or_none()
    if not getting_user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="no data is connected to this id")
    else: 
        return getting_user
    
@app.get("/blog/user", response_model=list[UserResponseSchema], status_code= status.HTTP_200_OK, tags=["users"])
def get_all_users(db: Session = Depends(get_db)):
    all_users = db.query(models.User).all()
    return all_users


@app.put("/blog/user/{id}", status_code= status.HTTP_200_OK, tags=["users"])
def update_user(id, request:UserRequestSchema, db: Session = Depends(get_db)):
    jsonable = jsonable_encoder(request)
    if 'password' in jsonable:
        jsonable['password'] = Hash.bcrypt(request.password)
    updated_user = db.query(models.User).filter(models.User.id == id)
    get_first = updated_user.first()
    if get_first:
       updated_user.update(jsonable, synchronize_session=False)
       
       db.commit()
       return{"message": "your fertillizer has been successfully updated"}
    else:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="this id is not found or is not updatable ")

    